# Public AI Skill Sample

This package is a platform-neutral example of an e-commerce analysis skill. It contains instructions, a manifest, and synthetic input/output examples.

## Contents

- `SKILL.md`: the analysis contract and output requirements
- `manifest.json`: portable metadata
- `examples/sample-input.json`: synthetic request
- `examples/sample-output.md`: expected response shape

## Installation

There is no executable installer and no network dependency. Copy the folder into the skills or prompts directory used by your own Agent framework, then map the input fields described in `manifest.json`.

If your framework uses a different skill format, treat `SKILL.md` as the system instruction and adapt `manifest.json` to the framework schema.

## Disclaimer

All examples are fictional. Review the prompt, data-access policy, and output schema before using the sample in a production environment.
