# Traffic-Support Conversion Summary

## Headline

On 2026-10-04, the 0+, 5+, and 10+ traffic-support conversion rates were 76.8%, 55.1%, and 36.7%.

## Diagnosis

The conversion rate declines as the order threshold rises. This comparison describes different thresholds and should not be read as a single sequential funnel without confirming denominator consistency.

## Recommended actions

- Compare each threshold with its historical baseline.
- Review the seller count behind each rate before prioritizing an intervention.
- Keep natural conversion and traffic-support conversion in separate monitoring views.

## Limitation

The sample does not include seller-level or creative-level records, so it cannot identify the exact seller or ad creative driving the change.
